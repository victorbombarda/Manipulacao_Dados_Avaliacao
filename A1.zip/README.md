# Manipulacao_Dados_Avaliacao
Repositório para o trabalho de avaliação da disciplina Manipulação de Dados, EMAp FGV-Rio.
